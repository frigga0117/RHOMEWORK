#' Do the shapiro-test for different groups, draw their frequency histograms and do t-test between two different groups.
#'
#' @param group A vector of the kind name of subjects.
#' @param value A vector of the value of subjects.
#' @return the results of shapiro.test and t.test and frequency histograms of each groups.
#' @examples
#' x <- c(1,2,1,2,1,2)
#' y <- c(3,5,3,4,5,4)
#' tcompare(x,y)
#' @export
tcompare <- function(group,value){
  tc.groupname <- unique(group)
  tc.nn <- length(unique(group))
  tc.datta <- data.frame(group,value)
  colnames(tc.datta) <- c("group","value")
  tc.tmp <- list()
  graphics::par(mfrow=c(1,tc.nn))
  for(i in 1:tc.nn){
    tc.tmp[[i]] <- subset(tc.datta, group==tc.groupname[i])
    graphics::hist(tc.tmp[[i]][,2],xlab="Levels",main=tc.groupname[i])
  }
  graphics::par(mfrow=c(1,1))
  for(i in 1:tc.nn){
    tc.tmp[[i]] <- subset(tc.datta, group==tc.groupname[i])
    names(tc.tmp)[i] <- tc.groupname[i]
    print(stats::shapiro.test(tc.tmp[[i]][,2]))
  }
  for(i in 1:(tc.nn-1)){
    tc.tmp[[i]] <- subset(tc.datta, group==tc.groupname[i])
    names(tc.tmp)[i] <- tc.groupname[i]
    for(j in (i+1):tc.nn){
      print(stats::t.test(x=tc.tmp[[i]][,2],y=tc.tmp[[j]][,2]))
    }
  }
}

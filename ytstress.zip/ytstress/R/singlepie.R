# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Cmd + Shift + B'
#   Check Package:             'Cmd + Shift + E'
#   Test Package:              'Cmd + Shift + T'

#' Draw a pie of a list of different kind subjects.
#'
#' @param group A vector of subjects.
#' @return The pie of \code{group}.
#' @examples
#' x <- c(1,1,2,2,2)
#' singlepie(x)
#' @export
singlepie <- function(group) {
  sp.groupname <- unique(group)
  sp.nn <- length(unique(group))
  sp.xx <- c()
  for(i in 1:sp.nn){
    sp.xx[i] <- length(which(group==sp.groupname[i]))
  }
  sp.pct1 <- round(sp.xx/sum(sp.xx)*100)
  sp.labell <- paste(sp.groupname," ",sp.pct1,"%")
  graphics::pie(sp.xx,labels=sp.labell,main="Pie")
}

#' Draw the boxplots of the value of different kind subjuects on one page.
#'
#' @param group A vector of the kind name of subjects.
#' @param value A vector of the value of subjects.
#' @return One picture of all boxplots of different groups.
#' @examples
#' x <- c(1,1,2,2,2)
#' y <- c(3,5,3,4,5)
#' multiboxplot(x,y)
#' @export
multiboxplot <- function(group,value) {
  mb.groupname <- unique(group)
  mb.nn <- length(unique(group))
  mb.datta <- data.frame(group,value)
  colnames(mb.datta) <- c("group","value")
  mb.tmp1 <- list()
  mb.tmp2 <- list()
  for(i in 1:mb.nn){
    mb.tmp1[[i]] <- subset(mb.datta, group==mb.groupname[i])
    mb.tmp2[[i]] <- mb.tmp1[[i]][,2]
    names(mb.tmp2)[i] <- mb.groupname[i]
  }
  graphics::par(mfrow=c(1,1))
  graphics::boxplot(mb.tmp2,main="Boxplot",ylab="Data")
}
